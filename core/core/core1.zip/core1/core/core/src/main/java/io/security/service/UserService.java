package io.security.service;


import io.security.domain.Account;

public interface UserService {
    void createUser(Account accout);

}
